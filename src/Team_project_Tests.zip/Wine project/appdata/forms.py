from flask_wtf import FlaskForm, Form
from wtforms import StringField, SubmitField, SelectField
from flask import Flask, render_template, flash, request
from wtforms.validators import InputRequired
from appdata import models
from appdata.models import DAO


class MenuForm(Form):
    menu = SelectField(u'Choices', choices=[('k1', 'Country'), ('k2', 'Winery'), ('k3', 'Region'), ('k4', 'Province')])
    btn = SubmitField('Search')


class theForm(FlaskForm):
    country = StringField('Country')  # the input field of the form (StringField)
    winery = StringField('Winery')
    region = StringField('Region')
    province = StringField('Province')
    btn = SubmitField('Search')  # the submit button for the form (SubmitField)


class getCountryForm(FlaskForm):

    def __init__(self, c_list):
        super(getCountryForm, self).__init__()
        self.c_list = c_list
        self.countries_field = SelectField('Countries', choices=self.c_list)
        self.btn = SubmitField('Search')

