from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from flask import Flask, render_template, flash, request
from wtforms.validators import InputRequired


class theForm(FlaskForm):
    country = StringField('Country')  # the input field of the form (StringField)
    winery = StringField('Winery')
    region = StringField('Region')
    province = StringField('Province')
    btn = SubmitField('Search')  # the submit button for the form (SubmitField)
