from flask import render_template, redirect
from appdata import app
from appdata.forms import testForm
from appdata.models import DAO


@app.route('/')
@app.route('/hello')
def hello():
    return render_template('placeholder.html', title='Hello')


@app.route('/test', methods=['GET', 'POST'])
def getPlayer():
    form = testForm()
    if not form.validate_on_submit():
        print('Not Validated')
        return render_template('country.html', title='Country', form=form)  # render a template to be used in html
    else:
        print('Validated')
        d = DAO()
        d.connect_to_db()
        result = d.getData()
        return render_template('result.html', title='Result', data=result)  # render a template to be used in html
