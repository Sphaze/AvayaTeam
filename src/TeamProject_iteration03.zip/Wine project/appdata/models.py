import json
import sqlite3
import psycopg2
from flask import jsonify


class DBConnectionError(Exception):
    pass


class DAO:
    def __init__(self):
        # self.host = kwargs['host']
        # self.db = kwargs['db']
        # self.user = kwargs['user']
        # self.passwd = kwargs['passwd']
        self.conn = None

    def connect_to_db(self):
        try:
            self.conn = sqlite3.connect('Database')
        except:
            raise DBConnectionError

        self.cur = self.conn.cursor()
        return True

    def close_db(self):
        self.conn.close()

    def getData(self, country):
        name_list = []
        # printer = []
        # sql_statement = '''SELECT Winery FROM Winery WHERE Country = %s'''
        sql_statement = 'SELECT Winery FROM Winery WHERE Country = ?'
        # test = "SELECT Winery FROM Winery WHERE Country = %s"
        # print('Country = ',country,  ' in getData')
        # print (type(country))
        self.cur.execute(sql_statement, (country,))

        # self.cur.execute(test)

        rows = self.cur.fetchall()
        # print(rows)


        for row in rows:
            #  printer = row
            (k) = row
            name_list.append([k])
        # return printed_list
        name_list_json = json.dumps(name_list[0:10])
        #   name_list_json = json.dumps(name_list[0])

        return name_list_json

        # name_list = printer[0]
        # return name_list


    # def getDecodedData(self, name_list):
    #
    #     z = json.loads(name_list)
    #
    #     # encoded = json.JSONEnconder.encode(z)
    #     final_data = json.JSONDecoder.raw_decode(name_list)
    #     return final_data


if __name__ == '__main__':
    import sys

    dao = DAO()
    try:
        dao.connect_to_db()
    except DBConnectionError:
        print('Error connecting to DB')
        sys.exit(1)
    else:
        print('Connected to the Database!')
        #   print(dao.getData())
        dao.close_db()
