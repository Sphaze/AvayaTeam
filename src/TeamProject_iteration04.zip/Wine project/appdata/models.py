import json
import sqlite3
import psycopg2
from flask import jsonify


class DBConnectionError(Exception):
    pass


class DAO:
    def __init__(self):
        # self.host = kwargs['host']
        # self.db = kwargs['db']
        # self.user = kwargs['user']
        # self.passwd = kwargs['passwd']
        self.conn = None

    def connect_to_db(self):
        try:
            self.conn = sqlite3.connect('Database')
        except:
            raise DBConnectionError

        self.cur = self.conn.cursor()
        return True

    def close_db(self):
        self.conn.close()

    def getData(self, country):
        name_list = []
        nwlist = []
        count = 0

        sql_statement = 'SELECT Winery, Region_1 FROM Winery WHERE Country = ?'

        self.cur.execute(sql_statement, (country,))
        rows = self.cur.fetchall()

        for row in rows:
            # (k) = row
            name_list.append(row)

        name_list_json = json.dumps(name_list)
        #   lst2 = [item[0] for item in name_list_json]  # extract list from sublist and put it in a separate list

        nwlist = json.loads(name_list_json)

        return nwlist
        # #text =
        # name_list_json = json.dumps(name_list[0])

        #
        # return moddedList[1]

        # for item in lst2:
        #     nwlist[count] = item
        #     count += 1

        # name_list = printer[0]
        # return name_list

    # def getDecodedData(self, name_list):
    #
    #     z = json.loads(name_list)
    #
    #     # encoded = json.JSONEnconder.encode(z)
    #     final_data = json.JSONDecoder.raw_decode(name_list)
    #     return final_data


if __name__ == '__main__':
    import sys

    dao = DAO()
    try:
        dao.connect_to_db()
    except DBConnectionError:
        print('Error connecting to DB')
        sys.exit(1)
    finally:
        print('Connected to the Database!')
        #   print(dao.getData())
        dao.close_db()
