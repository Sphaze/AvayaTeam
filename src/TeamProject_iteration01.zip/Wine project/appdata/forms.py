from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import InputRequired


class testForm(FlaskForm):
    country = StringField('Country', validators=[InputRequired()])    # the input field of the form (StringField)
    submit = SubmitField('Make query')  # the submit button for the form (SubmitField)
