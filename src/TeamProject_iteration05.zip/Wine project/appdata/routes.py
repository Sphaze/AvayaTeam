from flask import render_template, redirect
from appdata import app
from appdata.forms import theForm
from appdata.models import DAO


@app.route('/')
@app.route('/hello')
def hello():
    return render_template('placeholder.html', title='Hello')


@app.route('/search_form', methods=['GET', 'POST'])
def getData():
    form = theForm()

    if not form.validate_on_submit():  # this will be true if no text is entered in the input field
        print('Not Validated')
        return render_template('search_form.html', title='The Winery Locator', form=form)  # render a template
    else:
        print('Validated')  # the form validates because text was entered before clicking submit button
        # print ('country = ', form.country.data)
        d = DAO()
        d.connect_to_db()
        # make conditional statements here and implement different methods from the DAO to perform different tasks
        # print(form.country)
        # print(form.winery)
        # if form.winery.data == '':
        #     print("The winery field was left blank")
        #
        # if form.validate_on_submit() and form.country.data != '':

        if form.validate_on_submit() and form.country.data != '':
            countryData = form.country.data  # this argument will focus on the country field
            inputted_data = d.getWineryByCountry(countryData)
        if form.validate_on_submit() and form.winery.data != '':
            wineryData = form.winery.data
            inputted_data = d.getLocationByWinery(wineryData)
        if form.validate_on_submit() and form.region.data != '':
            regionData = form.region.data
            inputted_data = d.getResultsFromRegion(regionData)
        if form.validate_on_submit() and form.province.data != '':
            provinceData = form.province.data
            inputted_data = d.getResultsFromRegion(provinceData)

        return render_template('result.html', title='Results', data=inputted_data)  # render a template
