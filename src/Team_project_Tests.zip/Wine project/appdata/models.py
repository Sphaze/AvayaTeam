import json
import sqlite3


class DBConnectionError(Exception):
    pass


class DAO:
    def __init__(self):
        self.conn = None

    def connect_to_db(self):
        try:
            self.conn = sqlite3.connect('Database')
        except DBConnectionError:
            raise DBConnectionError

        self.cur = self.conn.cursor()
        return True

    def close_db(self):
        self.conn.close()

    def getWineryByCountry(self, req):  # this method is executed after the button has been pressed
        name_list = []

        sql_statement = 'SELECT Winery, Region_1 FROM Winery WHERE Country = ?'
        self.cur.execute(sql_statement, (req,))

        rows = self.cur.fetchall()

        for row in rows:
            # (k) = row
            name_list.append(row)

        name_list_json = json.dumps(name_list)

        nwlist = json.loads(name_list_json)
        return nwlist

    def getLocationByWinery(self, req):  # this method is executed after the button has been pressed
        name_list = []

        sql_statement = 'SELECT DISTINCT Country, Region_1 FROM Winery WHERE Winery = ?'
        self.cur.execute(sql_statement, (req,))

        rows = self.cur.fetchall()

        for row in rows:
            # (k) = row
            name_list.append(row)

        name_list_json = json.dumps(name_list)

        nwlist = json.loads(name_list_json)
        return nwlist

    def getResultsFromRegion(self, req):  # this method is executed after the button has been pressed
        name_list = []

        sql_statement = 'SELECT DISTINCT Winery FROM Winery WHERE Region_1 = ?'
        self.cur.execute(sql_statement, (req,))

        rows = self.cur.fetchall()

        for row in rows:
            # (k) = row
            name_list.append(row)

        name_list_json = json.dumps(name_list)

        nwlist = json.loads(name_list_json)
        return nwlist

    def getResultsFromProvince(self, req):  # this method is executed after the button has been pressed
        name_list = []

        sql_statement = 'SELECT DISTINCT Winery, Region_1 FROM Winery WHERE Province = ?'
        self.cur.execute(sql_statement, (req,))

        rows = self.cur.fetchall()

        for row in rows:
            # (k) = row
            name_list.append(row)

        name_list_json = json.dumps(name_list)

        nwlist = json.loads(name_list_json)
        return nwlist

    def getAllCountries(self):
        country_list = []

        sql_statement = "SELECT DISTINCT Country from Winery"

        self.cur.execute(sql_statement)
        rows = self.cur.fetchall()
        for row in rows:
            country_list.append(row)

        return json.loads(country_list)


if __name__ == '__main__':
    import sys
    dao = DAO()
    try:
        dao.connect_to_db()
    except DBConnectionError:
        print('Error connecting to DB')
        sys.exit(1)
    finally:
        print('Connected to the Database!')
        #   print(dao.getData())
        dao.close_db()
