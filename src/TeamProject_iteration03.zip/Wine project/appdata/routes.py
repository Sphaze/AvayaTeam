from flask import render_template, redirect
from appdata import app
from appdata.forms import testForm
from appdata.models import DAO


@app.route('/')
@app.route('/hello')
def hello():
    return render_template('placeholder.html', title='Hello')


@app.route('/country', methods=['GET', 'POST'])
def getPlayer():
    form = testForm()
    if not form.validate_on_submit(): # this will be true if no text is entered in the input field
        print('Not Validated')
        return render_template('country.html', title='Country', form=form)  # render a template to be used in html
    else:
        print('Validated')  # the form validates because text was entered before clicking submit button
        # print ('country = ', form.country.data)
        d = DAO()
        d.connect_to_db()

        input_scanner = form.country.data
        result = d.getData(input_scanner)

        # result = d.getData()

        return render_template('result.html', title='Result', data=result)  # render a template to be used in html
