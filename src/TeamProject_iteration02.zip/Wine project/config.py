import os


class Config:
    SECRET_KEY = 'foobar'
