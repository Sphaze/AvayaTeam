import json
import sqlite3
import psycopg2


class DBConnectionError(Exception):
    pass


class DAO:
    def __init__(self):
        # self.host = kwargs['host']
        # self.db = kwargs['db']
        # self.user = kwargs['user']
        # self.passwd = kwargs['passwd']
        self.conn = None

    def connect_to_db(self):
        try:
            self.conn = sqlite3.connect('Database')
        except:
            raise DBConnectionError

        self.cur = self.conn.cursor()
        return True

    def close_db(self):
        self.conn.close()

    def getData(self):
        name_list = []
        printer = ''
        # sql_statement = '''SELECT Winery FROM Winery WHERE Country = %s'''
        sql_statement = "SELECT Winery FROM Winery WHERE Country = 'Italy'"
        # test = "SELECT Winery FROM Winery WHERE Country = %s"

        self.cur.execute(sql_statement)
        # self.cur.execute(test)
        rows = self.cur.fetchall()
        for row in rows:
            #  printer = row
            (k) = row
            name_list.append([k])
        # printed_list = json.dumps(printer)
        # return printed_list
        name_list_json = json.dumps(name_list)
        return name_list_json


if __name__ == '__main__':
    import sys

    dao = DAO()
    try:
        dao.connect_to_db()
    except DBConnectionError:
        print('Error connecting to DB')
        sys.exit(1)
    else:
        print('Connected to the Database!')
        #   print(dao.getData())
        dao.close_db()
